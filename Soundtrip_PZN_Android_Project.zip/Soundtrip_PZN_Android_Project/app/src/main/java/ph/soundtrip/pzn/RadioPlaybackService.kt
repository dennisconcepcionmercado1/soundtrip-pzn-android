package ph.soundtrip.pzn

import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * Media playback service foundation.
 * Configure the verified direct Zeno stream URL in this service before enabling playback.
 */
class RadioPlaybackService : MediaSessionService() {
    private var player: ExoPlayer? = null
    private var mediaSession: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val exo = ExoPlayer.Builder(this).build()
        player = exo
        mediaSession = MediaSession.Builder(this, exo).build()
        // TODO: Add the verified direct audio stream URL as a MediaItem:
        // exo.setMediaItem(MediaItem.fromUri("https://YOUR-VERIFIED-ZENO-STREAM-URL"))
        // exo.prepare()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onDestroy() {
        mediaSession?.release()
        player?.release()
        mediaSession = null
        player = null
        super.onDestroy()
    }
}
