package ph.soundtrip.pzn

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val navy = 0xFF061A2D.toInt()
    private val gold = 0xFFF5B700.toInt()

    // Verified links available from the project conversation.
    private val zenoPage = "https://zeno.fm/radio/soundtripradio"
    private val pznFacebook = "https://www.facebook.com/philippinezellonetwork"
    private val pznMessenger = "https://m.me/j/Abb1mbcFkiNE39WK/"

    // Add the exact destination URLs before release.
    private val pznZello = ""
    private val srpFacebook = ""
    private val srpMessenger = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 30, 24, 24)
            setBackgroundColor(navy)
        }

        val title = TextView(this).apply {
            text = "SOUNDTRIP RADIO"
            textSize = 25f
            setTextColor(gold)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "PHILIPPINES  •  PZN"
            textSize = 15f
            setTextColor(-1)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 24)
        }
        page.addView(title, matchWrap())
        page.addView(subtitle, matchWrap())

        addButton(page, "▶  LISTEN LIVE — SOUNDTRIP RADIO") {
            // Until the direct Zeno audio stream URL is supplied, open the official player page.
            openLink(zenoPage)
        }
        addButton(page, "📡  PZN OFFICIAL ZELLO CHANNEL") {
            openOrWarn(pznZello, "Kailangan pa ang exact PZN Zello channel invitation link.")
        }
        addButton(page, "💬  PZN MESSENGER GROUP") { openLink(pznMessenger) }
        addButton(page, "f  PZN FACEBOOK PAGE") { openLink(pznFacebook) }
        addButton(page, "f  SOUNDTRIP RADIO FACEBOOK") {
            openOrWarn(srpFacebook, "Kailangan pa ang exact Soundtrip Radio Facebook page link.")
        }
        addButton(page, "✉  SOUNDTRIP RADIO MESSENGER") {
            openOrWarn(srpMessenger, "Kailangan pa ang exact Soundtrip Radio Messenger link.")
        }

        val note = TextView(this).apply {
            text = "Your Home for Good Music!\n\nLive audio background playback and lock-screen controls will be enabled after the direct Zeno stream URL is added."
            textSize = 12f
            setTextColor(0xFFB8C7D9.toInt())
            gravity = Gravity.CENTER
            setPadding(8, 20, 8, 0)
        }
        page.addView(note, matchWrap())
        setContentView(page)
    }

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 14f
            setTextColor(navy)
            setBackgroundColor(gold)
            setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = 10
        parent.addView(b, lp)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun openOrWarn(url: String, message: String) {
        if (url.isBlank()) Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        else openLink(url)
    }

    private fun openLink(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            Toast.makeText(this, "Walang app na makapagbubukas ng link na ito.", Toast.LENGTH_LONG).show()
        }
    }
}
