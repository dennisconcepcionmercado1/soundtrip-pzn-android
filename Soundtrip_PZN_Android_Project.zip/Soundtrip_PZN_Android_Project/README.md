# Soundtrip Radio Philippines & Philippine Zello Network

Android project scaffold for the unified Soundtrip Radio + PZN app.

## Current status
This is a starter Android project, **not yet a complete/release-ready APK**.
Three verified destinations are configured:
- Soundtrip Zeno page: https://zeno.fm/radio/soundtripradio
- PZN Facebook: https://www.facebook.com/philippinezellonetwork
- PZN Messenger: https://m.me/j/Abb1mbcFkiNE39WK/

The exact PZN Zello invitation URL, Soundtrip Facebook URL, Soundtrip Messenger URL,
and the direct Zeno audio stream URL are still required.

## Build on GitHub using a phone
1. Create a repository named `soundtrip-pzn-android`.
2. Upload all files/folders from this ZIP to the repository root (preserve folders).
3. Open the repository's **Actions** tab.
4. If prompted, enable GitHub Actions.
5. Select **Build Soundtrip PZN APK** and press **Run workflow**.
6. When the run completes, open it and download the `Soundtrip-PZN-debug-apk` artifact.
7. Extract the ZIP artifact and install `app-debug.apk` on the Android phone.

## Important
- The current radio button opens the official Zeno page, not a direct background audio stream.
- The Media3 playback service is included as a foundation, but the verified stream URL
  must be configured before background playback and lock-screen controls can work.
- Three unavailable links intentionally remain unconfigured; do not publish as final until supplied.
- Debug APK is for testing. A signed release APK should be prepared before public distribution.
